%% 1-dim random walk (diffusion) model of binary choices

% Apoorva Bhandarti
% Ashoka Univeristy 
% PSY-3102 Monsoon 2022

% The task: Picking ripe apples from trees 
% The model: 1-dim discrete random walk model

%% Basic housekeeping
clear
close all

%% Set constants
T = 1000; % Number of trials
N = 1000 ; % Number of maximum time steps (and samples) per trial
Q = [-1 1] ; % Evidence quantum size. Drift is zero. To change 'drift' just make these values imbalanced 
B = [-20 20]; % Decision bounds


%% Define variables 
E = NaN(N,1); % variable will store the accumulated evidence 
D = NaN(T,1); % variable will store the decision made 
R1 = NaN(T,1); % variable will store the response time for positive boundary
R2 = NaN(T,1); % variable will store the response time for negative boundary
count = 0; % variable for checking if positive/negative boundary
N1 = 0; % variable for checking how many positive trials 
N2 = 0; % variable for checking how many negative trials 
%% Start simulation 

%% Draw a figure to plot trace on
f = figure(); 
xlabel('Time', 'FontSize', 16); % Label the X-axis
ylabel('Evidence', 'FontSize', 16); % Label the Y-axis
xlim([0 N]); % Set the scale of the X-axis
ylim([B(1)-5, B(2)+5]) % Set the scale of the Y-axis
%line([0, N], [B(1) B(1)]) % Draw a line to represent the lower bound
hold on % to ensure we don't overwrite existing plot elements
%line([0, N], [B(2) B(2)]) % Draw a line to represrent the upper bound

%% Loop over trials
for trials = 1:T

    E = zeros(N,1) ; % For each trial create a placeholder vector to record accumulated evidence on each trial 
    
    E(1) = Q(unidrnd(2)) ; % Select first sample
    
    % Loop over time steps
    for samples = 2:N
        % Calculate accumulated evidence as current evidence + new sample
        % and store it in placeholder
        E(samples) = E(samples-1)+Q(unidrnd(2)) ;
        
        % Check if either bound is reached 
        if E(samples) >= B(2) 
            count = 0;
            N1 = N1 + 1;
            break % exit the loop
        end
        if E(samples) <= B(1)
            count = 1;
            N2 = N2 + 1;
            break
        end
    end
    
    D(trials, 1) = sign(E(samples)); % Record what decision was made 
    E = E(1:samples); % Trim the evidence variable upto the last time step 
    if count == 0 
        R1(trials, 1) = length(E); % Record how long the positive decision took
    end
    if count == 1
        R2(trials, 1) = length(E); % Record how long the negative decision took
    end
%% Plot the current trial's evidence trace 
    %plot(E, 'LineWidth', 1.5)
end

arr = R1.';
arr1 = reshape(arr,1,[]);
average = mean(arr);
skew = skewness(arr1);
SD = std(arr1);
histogram(R1)
total_picked = sum(D>0);
hold off 
xlim([-200 N])
ylim([0 600])
txt1 = ['N= ' num2str(N2)];
text(600,550,txt1)
txt2 = ['Mean= ' num2str(average)];
text(600,500,txt2)
txt3 = ['Std dev= ' num2str(SD)];
text(600,450,txt3)
txt4 = ['Skew= ' num2str(skew)];
text(600,400,txt4)
%title(sprintf('%1.0f apples picked out of 20 in %1.2f time steps on average', total_picked, mean(R)))