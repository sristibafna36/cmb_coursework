%% Cleanup 
clc; 
clear; 
close all; 

%% Plot the figure for a given model
model_number = 1; 
makeFigures(model_number); 
