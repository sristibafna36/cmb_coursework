function chosen_option = pick_choice(choice_probabilities)
    choice_random_number = rand;
    if choice_random_number < choice_probabilities(1)
        chosen_option = 1; 
    else
        chosen_option = 2; 
    end
end
