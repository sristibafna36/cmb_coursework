%% Cleanup 
clc; 
clear; 
close all; 

%% Plot the figure for a given model
model_number = 3; 
makeFigures(model_number); 
