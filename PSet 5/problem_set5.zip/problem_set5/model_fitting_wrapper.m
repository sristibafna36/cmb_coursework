% Model fitting tutorial
% Computational Modeling of Behavior
% Ashoka University, Fall 2022
% Apoorva Bhandari

% Goal of this script: Use fmincon to fit a model to data and estimate
% best-fitting parameters using maximum
% likleihood estimation 

% What we know: data
% - number of trials
% - choices that were made
% - rewards that were obtained

% What we specify: model & its fixed parameters
% - the model (model3: rescorla-wagnger + softmax)
% - initial values

% What we want to estimate: (free parameters)
% - learning rate (alpha)
% - inverse temperature (beta)

% The approach we will use to estimate the free parameters is known
% as the maximum likelihood estimation (mle). In mle, the goal is to
% find the values of the free parameters that maximize the probability
% that our chosen model generated the data. Mathematically, we are
% computing:

% argmax(log(p(data/model)))
% argmax here is to be read as "arguments for which the function has
% maximum value". The 'arguments' here are the free parameters, the
% function is the log likelihood function.

% we can rewrite this as:
% argmin(-log(p(data/model)))
% argmin is to be read as "arguments for which the function has minimum
% value". We turned maximum into minimum by adding a negative sign to the
% log likelihood function.

% Note that there will always be maximum likelihood estimates of the free
% parameters. That does not mean that they are accurate estimates. This is
% something we must evaluate.

%% Cleanup

clc; % clean the command window
clear; % clear workspace of all variables
close all; % close any open figures

%% Load in the data
load('ps5_sim_data_084.mat')
T = 1000;

%We specify how many times we will run the model fits
nIter = 100; 

%% We loop through the iterations
for iter = 1:nIter % run N times from random initial conditions, to get best fit
    
    % algorithm needs a starting point in the parameter space 
    % best to have it random(ish), and vary it between iterations
    
    % set the starting values of the two parameters.
    % this should be somewhat random to make sure each
    % iteration has a different starting point
    startingVals = [0.5+(rand-0.5)*0.5 5+(rand-0.5)*4];
    % also set the lower and upper bounds of each parameter
    
    lb = [0 0];
    ub = [1 10];
    
    % this is the fmincon syntax, 
    [res(iter,:),lik(iter),~,~,~,~,~] = ...
        fmincon(@(x) model3_loglike(choices, rewards,T, x(1),x(2)),startingVals,[],[],[],[],lb,ub);
    % note that this assumes that the call to model3_loglike will be of
    % this form: model3_loglike(data, T, alpha, beta)
    %      where choices containing the choices and
    %      rewards containing the rewards. If your loglike function
    %      has a different form, please adjust this accordingly. 
end

